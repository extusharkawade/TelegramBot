package Rajas.com.botRest.BotRest;

public interface SpringContextBridgedServices {
}
