package Rajas.com.botRest.BotRest;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class BotRestApplication  {

	public static void main(String[] args) {

		SpringApplication.run(BotRestApplication.class, args);
		//Main Class to run the bot

	}



}
