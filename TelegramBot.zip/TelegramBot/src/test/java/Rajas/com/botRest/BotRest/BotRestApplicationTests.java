package Rajas.com.botRest.BotRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BotRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
